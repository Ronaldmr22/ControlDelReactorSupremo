using System;
using UnityEngine;
using System.Collections;

public class SincronizacionJugadores : MonoBehaviour
{
    [SerializeField] private ClienteWebSocket cliente;
    [SerializeField] private GeneradorJugadores generador;
    [SerializeField]
    private ControladorGuardianes controladorGuardianes;

    [Serializable]
    private class MensajeRed
    {
        public string type;
        public string playerId;
        public string roomCode;
        public int idUsuario;
        public float x;
        public float y;
    }

    private string miIdWebSocket;
    private float siguienteEnvio;
    private Vector3 ultimaPosicionEnviada;
    private MovimientoJugador movimientoLocal;
    private Coroutine rutinaCongelamiento;

    private void OnEnable()
    {
        if (cliente != null)
            cliente.MensajeRecibido += ProcesarMensaje;
    }

    private void OnDisable()
    {
        if (cliente != null)
            cliente.MensajeRecibido -= ProcesarMensaje;

        if (movimientoLocal != null)
        {
            movimientoLocal.AccionEjecutada -= EnviarAccion;
            movimientoLocal = null;
        }
    }

    private void Update()
    {
        if (cliente == null ||
            !cliente.EstaConectado ||
            generador == null ||
            generador.JugadorLocal == null ||
            string.IsNullOrEmpty(miIdWebSocket))
            return;

        VincularAccionLocal();

        // Enviar posición 20 veces por segundo.
        if (Time.time < siguienteEnvio)
            return;

        siguienteEnvio = Time.time + 0.05f;

        Vector3 posicion = generador.JugadorLocal.position;

        Debug.Log($"POSICION ENVIADA UNITY: " +$"X={posicion.x:F2}, Y={posicion.y:F2}");

        ultimaPosicionEnviada = posicion;

        cliente.EnviarMensaje(JsonUtility.ToJson(new MensajeRed
        {
            type = "move",
            x = posicion.x,
            y = posicion.y
        }));
    }

    private void ProcesarMensaje(string json)
    {
        MensajeRed mensaje = JsonUtility.FromJson<MensajeRed>(json);
    
        if (mensaje.type == "player_frozen")
        {
            if (mensaje.playerId != miIdWebSocket)
                return;

            if (generador == null || generador.JugadorLocal == null)
                return;

            MovimientoJugador movimientoJugador =
                generador.JugadorLocal.GetComponent<MovimientoJugador>();

            if (movimientoJugador == null)
                return;

            if (rutinaCongelamiento != null)
                StopCoroutine(rutinaCongelamiento);

            rutinaCongelamiento =
                StartCoroutine(CongelarTemporalmente(movimientoJugador));

            return;
        }

        if (mensaje.type == "room_subscribed")
        {
            miIdWebSocket = mensaje.playerId;
            Debug.Log("Jugador registrado para sincronización.");
        }
        else if (mensaje.type == "player_joined")
        {
            if (mensaje.playerId == miIdWebSocket)
                return;

            if (generador != null)
                generador.CrearJugadorRemoto(
                    mensaje.playerId,
                    mensaje.idUsuario
                );
        }
        else if (mensaje.type == "player_moved")
        {
            if (mensaje.playerId == miIdWebSocket)
                return;

            if (generador == null)
                return;

            Transform remoto = generador.ObtenerJugadorRemoto(mensaje.playerId);

            if (remoto == null)
                return;

            Vector3 nuevaPosicion = new Vector3(
                mensaje.x,
                mensaje.y,
                remoto.position.z
            );

            // Calcula hacia dónde se desplazó el jugador remoto.
            Vector2 direccion = new Vector2(
                nuevaPosicion.x - remoto.position.x,
                nuevaPosicion.y - remoto.position.y);

            var movimientoRemoto = remoto.GetComponent<MovimientoJugador>();

            if (movimientoRemoto != null)
                movimientoRemoto.ActualizarDireccionVisual(direccion);

            remoto.position = nuevaPosicion;
        }
        else if (mensaje.type == "player_left")
        {
            if (generador != null)
                generador.EliminarJugadorRemoto(mensaje.playerId);
        }
    }

    private void EnviarAccion()
    {
        if (cliente == null ||
            !cliente.EstaConectado ||
            string.IsNullOrEmpty(miIdWebSocket))
            return;

        cliente.EnviarMensaje(JsonUtility.ToJson(new MensajeRed
        {
            type = "action"
        }));
    }

    private void VincularAccionLocal()
    {
        if (generador == null || generador.JugadorLocal == null)
            return;

        MovimientoJugador movimiento =
            generador.JugadorLocal.GetComponent<MovimientoJugador>();

        if (movimiento == movimientoLocal)
            return;

        if (movimientoLocal != null)
            movimientoLocal.AccionEjecutada -= EnviarAccion;

        movimientoLocal = movimiento;

        if (movimientoLocal != null)
            movimientoLocal.AccionEjecutada += EnviarAccion;
    }
    private System.Collections.IEnumerator CongelarTemporalmente(
    MovimientoJugador jugador)
    {
        jugador.EstablecerCongelado(true);

        Debug.Log("Jugador congelado durante 2 segundos.");

        yield return new WaitForSecondsRealtime(2f);

        if (jugador != null)
            jugador.EstablecerCongelado(false);

        rutinaCongelamiento = null;

        Debug.Log("Jugador descongelado.");
    }


}
